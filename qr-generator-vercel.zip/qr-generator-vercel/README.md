# QR Code Generator 📱

A modern, easy-to-use QR code generator built with React. Create QR codes for URLs, text, and WiFi networks instantly!

## ✨ Features

- **General QR Codes**: Create QR codes for any text, URL, phone number, or email
- **WiFi QR Codes**: Generate QR codes for automatic WiFi connection
- **Multiple Download Formats**: Export as PNG, JPEG, or PDF
- **Responsive Design**: Works perfectly on desktop and mobile
- **No Backend Required**: Completely client-side, fast and private
- **Free & Open Source**: Use it anywhere, anytime

## 🚀 Live Demo

Coming soon after deployment!

## 📦 Deployment to Vercel (Recommended)

### Method 1: Deploy via Vercel Website (Easiest)

1. **Create a GitHub account** (if you don't have one)
   - Go to [github.com](https://github.com) and sign up

2. **Create a new repository**
   - Click "New Repository"
   - Name it: `qr-code-generator`
   - Make it Public
   - Click "Create repository"

3. **Upload your files to GitHub**
   - Download all files from this folder
   - Drag and drop them into your GitHub repository
   - Commit the changes

4. **Deploy to Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Click "Sign Up" and choose "Continue with GitHub"
   - Click "Add New Project"
   - Import your `qr-code-generator` repository
   - Click "Deploy"
   - Wait 1-2 minutes for deployment

5. **Done! 🎉**
   - You'll get a URL like: `qr-code-generator.vercel.app`
   - Share it with anyone!

### Method 2: Deploy via Vercel CLI

```bash
# Install Vercel CLI
npm install -g vercel

# Navigate to project folder
cd qr-generator-vercel

# Deploy
vercel

# Follow the prompts and you're done!
```

## 🛠️ Local Development

Want to run it locally first?

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Open http://localhost:5173 in your browser
```

## 📁 Project Structure

```
qr-generator-vercel/
├── index.html          # Main HTML file
├── package.json        # Dependencies
├── vite.config.js      # Build configuration
├── src/
│   ├── main.jsx       # React entry point
│   └── App.jsx        # Main QR generator component
└── README.md          # This file
```

## 🎨 Customization

### Change Colors
Edit the gradient in `src/App.jsx`:
```jsx
<div className="bg-gradient-to-r from-blue-600 to-indigo-600">
```
Change `blue-600` and `indigo-600` to your preferred colors.

### Add Your Branding
In `src/App.jsx`, update the header section with your name/company.

### Custom Domain
Once deployed on Vercel:
1. Go to your project settings
2. Click "Domains"
3. Add your custom domain (e.g., `myqrgenerator.com`)
4. Follow Vercel's DNS instructions

## 💡 Usage Tips

### General QR Codes
- URLs: `https://example.com`
- Phone: `+1234567890`
- Email: `hello@example.com`
- Text: Any text you want

### WiFi QR Codes
1. Enter your WiFi network name
2. Enter password (leave blank for open networks)
3. Select security type (usually WPA/WPA2)
4. Generate and download
5. Print and display for guests!

## 🔒 Privacy

- All QR code generation happens in your browser
- No data is sent to any server
- Your WiFi passwords stay private
- No tracking or analytics

## 🐛 Troubleshooting

**QR code not generating?**
- Make sure you've entered text/URL or WiFi details
- Check your internet connection (needed for first load)
- Try refreshing the page

**Download not working?**
- Make sure you've generated a QR code first
- Check your browser's download permissions
- Try a different format (PNG/JPEG/PDF)

## 📝 License

MIT License - feel free to use this project however you want!

## 🤝 Contributing

Found a bug or want to add a feature? Feel free to:
1. Fork the repository
2. Make your changes
3. Submit a pull request

## 📧 Support

Questions? Issues? Open an issue on GitHub or reach out!

---

**Made with ❤️ by Shreerang**

Powered by React, Vite, and Vercel
