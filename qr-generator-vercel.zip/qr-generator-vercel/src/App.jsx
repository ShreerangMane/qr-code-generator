import React, { useState, useEffect, useRef } from 'react';
import { Wifi, Type, Download, QrCode } from 'lucide-react';

const App = () => {
  const [activeTab, setActiveTab] = useState('general');
  const [generalText, setGeneralText] = useState('');
  const [wifiConfig, setWifiConfig] = useState({
    ssid: '',
    password: '',
    security: 'WPA'
  });
  const [qrCodeData, setQrCodeData] = useState('');
  const [downloadFormat, setDownloadFormat] = useState('png');
  const canvasRef = useRef(null);

  useEffect(() => {
    if (qrCodeData && window.QRCode) {
      generateQRCode(qrCodeData);
    }
  }, [qrCodeData]);

  const generateQRCode = (data) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Clear previous QR code
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Create temporary container for QRCode.js
    const tempDiv = document.createElement('div');
    document.body.appendChild(tempDiv);

    const qr = new window.QRCode(tempDiv, {
      text: data,
      width: 300,
      height: 300,
      colorDark: '#000000',
      colorLight: '#ffffff',
      correctLevel: window.QRCode.CorrectLevel.H
    });

    // Wait for QR code to be generated, then draw to canvas
    setTimeout(() => {
      const img = tempDiv.querySelector('img');
      if (img) {
        ctx.drawImage(img, 0, 0);
      }
      document.body.removeChild(tempDiv);
    }, 100);
  };

  const handleGenerateGeneral = () => {
    if (generalText.trim()) {
      setQrCodeData(generalText.trim());
    }
  };

  const handleGenerateWiFi = () => {
    const { ssid, password, security } = wifiConfig;
    if (ssid) {
      // WiFi QR code format: WIFI:T:WPA;S:mynetwork;P:mypassword;;
      const wifiString = `WIFI:T:${security};S:${ssid};P:${password};;`;
      setQrCodeData(wifiString);
    }
  };

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const timestamp = Date.now();
    
    if (downloadFormat === 'png' || downloadFormat === 'jpeg') {
      // Download as PNG or JPEG
      const mimeType = downloadFormat === 'png' ? 'image/png' : 'image/jpeg';
      const extension = downloadFormat;
      
      canvas.toBlob((blob) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `qrcode-${timestamp}.${extension}`;
        a.click();
        URL.revokeObjectURL(url);
      }, mimeType, 0.95);
      
    } else if (downloadFormat === 'pdf') {
      // Download as PDF
      if (window.jspdf) {
        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF({
          orientation: 'portrait',
          unit: 'mm',
          format: 'a4'
        });
        
        // Add title
        pdf.setFontSize(16);
        pdf.text('QR Code', 105, 20, { align: 'center' });
        
        // Convert canvas to image and add to PDF
        const imgData = canvas.toDataURL('image/png');
        const imgWidth = 100;
        const imgHeight = 100;
        const x = (210 - imgWidth) / 2; // Center on A4 width (210mm)
        const y = 40;
        
        pdf.addImage(imgData, 'PNG', x, y, imgWidth, imgHeight);
        
        // Add instruction text
        pdf.setFontSize(10);
        pdf.text('Scan this QR code with your smartphone camera', 105, y + imgHeight + 15, { align: 'center' });
        
        pdf.save(`qrcode-${timestamp}.pdf`);
      }
    }
  };

  const handleKeyPress = (e, handler) => {
    if (e.key === 'Enter') {
      handler();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-8 text-white">
            <div className="flex items-center gap-3 mb-2">
              <QrCode size={40} />
              <h1 className="text-3xl font-bold">QR Code Generator</h1>
            </div>
            <p className="text-blue-100">Create QR codes instantly for any purpose</p>
          </div>

          {/* Tabs */}
          <div className="flex border-b border-gray-200">
            <button
              onClick={() => setActiveTab('general')}
              className={`flex-1 flex items-center justify-center gap-2 px-6 py-4 font-medium transition-all ${
                activeTab === 'general'
                  ? 'bg-white text-blue-600 border-b-2 border-blue-600'
                  : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
              }`}
            >
              <Type size={20} />
              General QR Code
            </button>
            <button
              onClick={() => setActiveTab('wifi')}
              className={`flex-1 flex items-center justify-center gap-2 px-6 py-4 font-medium transition-all ${
                activeTab === 'wifi'
                  ? 'bg-white text-blue-600 border-b-2 border-blue-600'
                  : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
              }`}
            >
              <Wifi size={20} />
              WiFi QR Code
            </button>
          </div>

          <div className="p-8">
            {/* General QR Code Tab */}
            {activeTab === 'general' && (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Enter Text or URL
                  </label>
                  <textarea
                    value={generalText}
                    onChange={(e) => setGeneralText(e.target.value)}
                    onKeyPress={(e) => handleKeyPress(e, handleGenerateGeneral)}
                    placeholder="Enter website URL, text, phone number, email, or any other data..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                    rows="4"
                  />
                  <p className="mt-2 text-sm text-gray-500">
                    Examples: https://example.com, +1234567890, email@example.com, or any text
                  </p>
                </div>
                <button
                  onClick={handleGenerateGeneral}
                  disabled={!generalText.trim()}
                  className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-semibold py-3 px-6 rounded-lg transition-colors"
                >
                  Generate QR Code
                </button>
              </div>
            )}

            {/* WiFi QR Code Tab */}
            {activeTab === 'wifi' && (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Network Name (SSID)
                  </label>
                  <input
                    type="text"
                    value={wifiConfig.ssid}
                    onChange={(e) => setWifiConfig({ ...wifiConfig, ssid: e.target.value })}
                    placeholder="Enter your WiFi network name"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Password
                  </label>
                  <input
                    type="text"
                    value={wifiConfig.password}
                    onChange={(e) => setWifiConfig({ ...wifiConfig, password: e.target.value })}
                    placeholder="Enter WiFi password (leave empty for open network)"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Security Type
                  </label>
                  <select
                    value={wifiConfig.security}
                    onChange={(e) => setWifiConfig({ ...wifiConfig, security: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
                  >
                    <option value="WPA">WPA/WPA2</option>
                    <option value="WEP">WEP</option>
                    <option value="nopass">None (Open Network)</option>
                  </select>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <p className="text-sm text-blue-800">
                    <strong>How it works:</strong> Visitors can scan this QR code with their phone camera to automatically connect to your WiFi network without typing the password.
                  </p>
                </div>

                <button
                  onClick={handleGenerateWiFi}
                  disabled={!wifiConfig.ssid.trim()}
                  className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-semibold py-3 px-6 rounded-lg transition-colors"
                >
                  Generate WiFi QR Code
                </button>
              </div>
            )}

            {/* QR Code Display */}
            {qrCodeData && (
              <div className="mt-8 pt-8 border-t border-gray-200">
                <div className="flex flex-col items-center">
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">Your QR Code</h3>
                  <div className="bg-white p-6 rounded-lg shadow-md border-2 border-gray-200">
                    <canvas
                      ref={canvasRef}
                      width="300"
                      height="300"
                      className="max-w-full"
                    />
                  </div>
                  
                  {/* Format Selector */}
                  <div className="mt-6 w-full max-w-xs">
                    <label className="block text-sm font-semibold text-gray-700 mb-2 text-center">
                      Download Format
                    </label>
                    <select
                      value={downloadFormat}
                      onChange={(e) => setDownloadFormat(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white text-center"
                    >
                      <option value="png">PNG Image</option>
                      <option value="jpeg">JPEG Image</option>
                      <option value="pdf">PDF Document</option>
                    </select>
                  </div>
                  
                  <button
                    onClick={handleDownload}
                    className="mt-4 flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors"
                  >
                    <Download size={20} />
                    Download as {downloadFormat.toUpperCase()}
                  </button>
                  <p className="mt-4 text-sm text-gray-500 text-center max-w-md">
                    Point your smartphone camera at the QR code to scan it
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Tips Section */}
        <div className="mt-8 bg-white rounded-xl shadow-lg p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-4">💡 Quick Tips</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="font-semibold text-gray-800 mb-2">General QR Codes</h3>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Share website links instantly</li>
                <li>• Add contact information</li>
                <li>• Share social media profiles</li>
                <li>• Create event invitations</li>
              </ul>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="font-semibold text-gray-800 mb-2">WiFi QR Codes</h3>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Print and display in your home</li>
                <li>• Perfect for guest rooms</li>
                <li>• Use in cafes or offices</li>
                <li>• No more password sharing hassle</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
